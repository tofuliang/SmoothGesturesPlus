#!/usr/bin/python

import sys
import os
import stat
import re

srcexec = os.path.dirname(os.path.abspath(__file__))+'/src'
destexec = '/opt/smoothgesturesplus-extras'

installdir = '/etc/opt/chrome/native-messaging-hosts'
hostname = 'com.smoothgesturesplus.extras'
destman = installdir+"/"+hostname+".json"
manifest = '{"name":"'+hostname+'", "description":"Extra Functionality for SmoothGestures Plus", "path":"'+destexec+'/sgplus-extras.py", "type":"stdio", "allowed_origins":["chrome-extension://mfpidjeogohllkpadkngkogjnpalnhfh/","chrome-extension://kdcjmllhmhnnadianfhhnoefgcdbpdap/","chrome-extension://ijgdgeacmjiigjjepffiijkleklaapfl/","chrome-extension://obmllkanogdgnalmjjhokaeelnkjpjji/"]}'

if os.getuid():
  sudo = "sudo"
  if not os.system("command -v kdesudo >/dev/null 2>&1"):
    sudo = "kdesudo"
  elif not os.system("command -v gksudo >/dev/null 2>&1"):
    sudo = "gksudo"
  else:
    print "This installer must be run as the superuser"
    sys.exit()
  os.system("%s %s" % (sudo, __file__))
  sys.exit()

def InstallNative():
  print "Installing."
  os.system("mkdir -p %s" % destexec)
  os.system("cp %s %s" % (srcexec+'/sgplus-extras.py', destexec))
  os.system("cp -r %s %s" % (srcexec+'/lib', destexec))
  os.system("chmod o+r -R %s" % destexec)

  os.system("mkdir -p %s" % installdir)
  with open(destman, "w") as f:
    f.write(manifest)
  os.system("chmod o+r %s" % destman)

def UninstallNative():
  os.system("rm -r %s" % destexec)
  os.system("rm %s" % destman)

InstallNative()
#UninstallNative()



